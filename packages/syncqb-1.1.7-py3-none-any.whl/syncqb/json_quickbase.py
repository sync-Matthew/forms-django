from .quickbase import QuickbaseClient
from .qb_errors import QBAuthError, QuickbaseError
from .xml_quickbase import XmlQuickbaseClient
from .helpers import SessionContext
import json
import sys


class JsonQuickbaseClient(QuickbaseClient):

    def __init__(
        self,
        credentials=None,
        timeout=None,
        default=None,
        session=None,
        user_agent=None,
        **kwargs,
    ):
        if not credentials:
            credentials = kwargs
        super().__init__(credentials, timeout=timeout, session=session)
        self.headers = {
            "QB-Realm-Hostname": self.realmhost,
            "Content-Type": "application/json",
            "User-Agent": user_agent or "syncqb-sdk",
        }

        if self.user_token is not None:
            self.headers.update({"Authorization": f"QB-USER-TOKEN {self.user_token}"})
        else:
            raise QBAuthError(
                "In order to use this SDK, you must provide a Quickbase user token."
            )

        self.default = default

    def __name__(self) -> str:
        return "JsonQuickbaseClient"

    # ---------------------------------------- formatting functions ----------------------------------------
    def nest(self, data_list):
        for index, data in enumerate(data_list):
            data_list[index] = self.nest_record(data)

        return data_list

    def denest(self, data_list):
        for index, data in enumerate(data_list):
            data_list[index] = self.denest_record(data)

        return data_list

    def replace_empty_values(self, data_list, default_value):
        for index, data in enumerate(data_list):
            data_list[index] = self.replace_empty_values_record(data, default_value)

        return data_list

    def none_to_0(self, data_list):
        return self.replace_empty_values(data_list, 0)

    def round_ints(self, data_list):
        for index, data in enumerate(data_list):
            data_list[index] = self.round_ints_record(data)

        return data_list

    def nest_record(self, data):
        return {key: {"value": value} for key, value in data.items()}

    def denest_record(self, data):
        return {key: value["value"] for key, value in data.items()}

    def replace_empty_values_record(self, data, default_value):
        return {
            key: default_value if value is None else value
            for key, value in data.items()
        }

    def none_to_0_record(self, data):
        return self.replace_empty_values_record(data, 0)

    def round_ints_record(self, data):
        for key, value in data.items():
            if isinstance(value, float) and value.is_integer():
                data[key] = int(value)
        return data

    # ---------------------------------------- info gathering functions ----------------------------------------
    def _get_sort_list(self, fids, ascending):
        if not fids or not isinstance(fids, (list, dict)):
            return [{"fieldId": "3", "order": "ASC"}]
        if isinstance(fids, dict):
            return [
                {"fieldId": str(fid), "order": "DESC" if order == "DESC" else "ASC"}
                for fid, order in fids.items()
            ]
        else:
            order = "ASC" if ascending else "DESC"
            return [{"fieldId": str(fid), "order": order} for fid in fids]

    @SessionContext.with_session
    def get_schema(
        self,
        database=None,
        preferences=None,
        app_id=None,
    ):
        preferences = preferences or ["fields"]
        schema = {}
        if "fields" in preferences:
            field_params = {
                "tableId": database or self.database,
                "includeFieldPerms": "true"
                if "permissions" in preferences
                else "false",
            }
            field_response = self._request(
                "https://api.quickbase.com/v1/fields",
                "get",
                self.headers,
                params=field_params,
                json=True,
            )
            schema.update({"fields": field_response})

        if "reports" in preferences:
            report_params = {
                "tableId": database or self.database,
            }
            report_response = self._request(
                "https://api.quickbase.com/v1/reports",
                "get",
                self.headers,
                params=report_params,
                json=True,
            )
            schema.update({"reports": report_response})

        if "table" in preferences:
            if not app_id:
                raise ValueError("You must provide app_id to get table schema")
            table_params = {
                "appId": app_id,
            }
            table_response = self._request(
                f"https://api.quickbase.com/v1/tables/{database or self.database}",
                "get",
                self.headers,
                params=table_params,
                json=True,
            )
            schema.update({"table": table_response})

        if "app" in preferences:
            if not app_id:
                raise ValueError("You must provide app_id to get app schema")
            app_response = self._request(
                f"https://api.quickbase.com/v1/apps/{app_id}",
                "get",
                self.headers,
                json=True,
            )
            schema.update({"app": app_response})

        return schema

    @SessionContext.with_session
    def get_primary_key(self, database=None):
        schema = self.get_schema(database)
        for field in schema.get("fields", []):
            if field.get("properties", {}).get("primaryKey"):
                return str(field.get("id"))

    def _get_report_query(self, qid, database=None):
        params = {
            "tableId": database or self.database,
        }
        url = f"https://api.quickbase.com/v1/reports/{qid}"
        response = self._request(url, "get", self.headers, params=params, json=True)

        return {
            "where": response["query"]["filter"],
            "sortBy": response["query"]["sortBy"],
            "groupBy": response["query"]["groupBy"],
        }

    # ---------------------------------------- query functions ----------------------------------------
    @SessionContext.with_session
    def do_query(
        self,
        query=None,
        qid=None,
        columns=None,
        sort=None,
        num=None,
        skip=None,
        ascending=True,
        database=None,
        round_ints=True,
        require_all=False,
        default=None,
    ):
        request_params, report = self._load_request_params(
            sort, ascending, query, qid, columns, num, skip, database, default
        )
        response = self._request(**request_params)

        data = []
        for record in response.get("data", []):
            data.append(json.dumps(record))

        if require_all:
            goal = num or 0
            offset = skip or 0
            metadata = response.get("metadata", {})
            total = metadata.get("totalRecords")
            num = metadata.get("numRecords")

            if goal and goal <= total - offset:
                goal -= num
            else:
                goal = total - num - offset

            offset += num
            while goal > 0:
                if report:
                    request_params["params"].update({"skip": offset, "top": goal})
                else:
                    request_params["data"].update(
                        {"options": {"skip": offset, "top": goal}}
                    )
                response = self._request(**request_params)
                num_records = response.get("metadata", {}).get("numRecords", 0)
                offset += num_records
                goal -= num_records

                for record in response.get("data", []):
                    record_str = json.dumps(record)
                    if record_str not in data:
                        data.append(record_str)

        return [
            self._post_process_record(
                record, default=default, round_ints=round_ints, stringify=True
            )
            for record in data
        ]

    @SessionContext.with_session
    def do_query_gen(
        self,
        query=None,
        qid=None,
        columns=None,
        sort=None,
        num=None,
        skip=None,
        ascending=True,
        database=None,
        round_ints=True,
        require_all=False,
        default=None,
    ):
        request_params, report = self._load_request_params(
            sort, ascending, query, qid, columns, num, skip, database, default
        )

        response = self._request(**request_params)

        for record in response.get("data", []):
            yield self._post_process_record(
                record, default=default, round_ints=round_ints
            )

        if require_all:
            goal = num or 0
            offset = skip or 0
            metadata = response.get("metadata", {})
            total = metadata.get("totalRecords")
            num = metadata.get("numRecords")

            if goal and goal <= total - offset:
                goal -= num
            else:
                goal = total - num - offset

            offset += num
            while goal > 0:
                if report:
                    request_params["params"].update({"skip": offset, "top": goal})
                else:
                    request_params["data"].update(
                        {"options": {"skip": offset, "top": goal}}
                    )
                response = self._request(**request_params)
                num_records = response.get("metadata", {}).get("numRecords", 0)
                offset += num_records
                goal -= num_records

                for record in response.get("data", []):
                    yield self._post_process_record(
                        record, default=default, round_ints=round_ints
                    )

        return

    def _load_request_params(
        self,
        sort,
        ascending,
        query,
        qid,
        columns,
        num,
        skip,
        database,
        default,
    ):
        if sort is None:
            sort = [3]
        if default is None:
            default = self.default

        report = False
        if query:
            body = {
                "from": database,
                "select": [column for column in (columns or [])],
                "where": query,
                "sortBy": self._get_sort_list(sort, ascending),
                "options": {"skip": int(skip or 0), "top": int(num or 0)},
            }
        elif qid and not columns:
            body = {
                "tableId": database,
            }
            if skip:
                body["skip"] = int(skip or 0)
            if num:
                body["top"] = int(num or 0)
            report = True
        elif qid and columns:
            query_info = self._get_report_query(qid, database)
            body = {
                "from": database,
                "select": [column for column in (columns or [])],
                "where": query_info["where"],
                "sortBy": query_info["sortBy"],
                "options": {"skip": int(skip or 0), "top": int(num or 0)},
            }
            if query_info.get("groupBy"):
                body["groupBy"] = query_info["groupBy"]
        else:
            raise ValueError("Must provide either a query or a qid")

        request_params = {}
        if report:
            request_params = {
                "url": f"https://api.quickbase.com/v1/reports/{qid}/run",
                "action": "post",
                "headers": self.headers,
                "params": body,
                "json": True,
            }
        else:
            request_params = {
                "url": "https://api.quickbase.com/v1/records/query",
                "action": "post",
                "headers": self.headers,
                "data": body,
                "json": True,
            }

        return request_params, report

    def _post_process_record(self, record, default, round_ints=False, stringify=False):
        if stringify:
            record = json.loads(record)
        record = self.denest_record(record)
        record = self.replace_empty_values_record(record, default)
        if round_ints:
            record = self.round_ints_record(record)
        return record

    # ---------------------------------------- single record functions ----------------------------------------
    @SessionContext.with_session
    def add_record(
        self,
        fields,
        database=None,
        uploads=None,
        safemode=False,
        return_fields=None,
        record_owner=None,
    ):

        if safemode:
            pk = self.get_primary_key(database)
            if pk in fields.keys():
                raise ValueError(f"Primary key fid: {pk} cannot be set in safemode")

        response = self._insert_update_record(
            fields, uploads, return_fields, database=database
        )
        response_metadata = response.get("metadata", {})

        if len(response_metadata.get("createdRecordIds")) != 1:
            raise QuickbaseError(
                "Expected exactly one record created, but got: "
                + f"{len(response_metadata.get('createdRecordIds') or [])}."
                + f" metadata: {response.get('metadata')}"
            )

        rid = response_metadata.get("createdRecordIds")[0]
        if record_owner:
            self.change_record_owner(rid, record_owner, database=database)
        if return_fields:
            return self.denest(response["data"])[0]
        else:
            return rid

    @SessionContext.with_session
    def edit_record(
        self,
        rid=None,
        key=None,
        key_fid=None,
        fields=None,
        database=None,
        uploads=None,
        return_fields=None,
        safemode=True,
    ):
        if not fields:
            fields = {}

        if not rid and not key and safemode:
            raise ValueError("Must provide either a rid or a key")
        if not rid and key and not key_fid:
            raise ValueError(
                "Must provide the primary key field ID to key_fid if key is provided"
            )
        fields.update({str(key_fid or 3): key or rid})

        response = self._insert_update_record(
            fields, uploads, return_fields, database=database
        )
        response_metadata = response.get("metadata", {})
        updated = response_metadata.get("updatedRecordIds")
        unchanged = response_metadata.get("unchangedRecordIds")

        if len(updated) + len(unchanged) != 1:
            raise QuickbaseError(
                "Expected exactly one record updated, but got: "
                + f"{len(updated) + len(unchanged)}."
                + f" metadata: {response.get('metadata')}",
                response,
            )

        if return_fields:
            return self.denest(response.get("data") or [])[0]
        else:
            try:
                return response_metadata.get("updatedRecordIds")[0]
            except IndexError:
                return response_metadata.get("unchangedRecordIds")[0]

    def _insert_update_record(self, body, uploads, return_fields, database=None):

        if uploads:
            for upload in uploads:
                body.update(
                    {
                        upload["field"]: {
                            "fileName": upload["filename"],
                            "data": (
                                upload["value"]
                                if not isinstance(upload["value"], bytes)
                                else upload["value"].decode("utf-8")
                            ),
                        }
                    }
                )

        return self._insert_update_records([body], return_fields, database=database)

    @SessionContext.with_session
    def delete_record(self, rid, database=None):
        body = {"from": database or self.database, "where": "{3.EX.%s}" % rid}
        url = "https://api.quickbase.com/v1/records"
        response = self._request(url, "delete", self.headers, data=body, json=True)

        return response

    # ---------------------------------------- multiple record functions ----------------------------------------
    @SessionContext.with_session
    def add_multiple_records(
        self,
        data,
        database=None,
        return_fields=None,
        round_ints=False,
        safemode=False,
        record_owner=None,
    ):

        if safemode:
            pk = self.get_primary_key(database)
            for index, record in enumerate(data):
                if pk in record.keys():
                    raise ValueError(
                        f"Primary key fid: {pk} cannot be set in safemode (record {index})"
                    )

        response = self._insert_update_records(data, return_fields, database)

        response["data"] = self.denest(response.get("data"))
        if round_ints:
            response["data"] = self.round_ints(response.get("data"))

        if record_owner:
            rids = response.get("metadata", {}).get("createdRecordIds")
            for rid in rids:
                self.change_record_owner(rid, record_owner, database=database)
        return response

    @SessionContext.with_session
    def edit_multiple_records(
        self, data, database=None, return_fields=None, round_ints=False, primary_key="3"
    ):
        pk = primary_key
        for record in data:
            if pk not in record.keys():
                raise ValueError(
                    f"Primary key fid: {pk} must be set in edit_multiple_records"
                )

        response = self._insert_update_records(data, return_fields, database)

        response["data"] = self.denest(response["data"])
        if round_ints:
            response["data"] = self.round_ints(response["data"])
        return response

    def _insert_update_records(self, records, return_fields, database=None):
        if return_fields is None:
            return_fields = [3]

        if len(records):
            for value in records[0].values():
                if not isinstance(value, dict) or value.get("value") is None:
                    records = self.nest(records)
                    break

        url = "https://api.quickbase.com/v1/records"
        body = {
            "to": database or self.database,
            "data": records,
            "fieldsToReturn": return_fields,
        }

        # make sure body does not exceed 10mb
        size = sys.getsizeof(json.dumps(body))
        if size > 10 * 1024 * 1024:
            raise QuickbaseError("Record data is too large")

        response = self._request(url, "post", self.headers, data=body, json=True)
        response_metadata = response.get("metadata", {})
        if response_metadata.get("lineErrors"):
            key = list(response_metadata["lineErrors"].keys())[0]
            raise QuickbaseError(
                f'Your record has invalid data: {response_metadata["lineErrors"][key]}'
            )

        return response

    @SessionContext.with_session
    def purge_records(self, database=None, rids=None, query=None):
        if not rids and not query:
            raise ValueError("Must provide either a list of rids or a query")

        if rids:
            rids = [str(rid) for rid in rids]
            query = "OR".join(["{3.EX.%s}" % rid for rid in rids])

        body = {"from": database or self.database, "where": query}
        url = "https://api.quickbase.com/v1/records"
        response = self._request(url, "delete", self.headers, data=body, json=True)

        return response

    # ---------------------------------------- file functions ----------------------------------------
    @SessionContext.with_session
    def upload_file(self, rid, upload, database=None):
        record = {
            "3": rid,
            upload["field"]: {"fileName": upload["filename"], "data": upload["value"]},
        }
        response = self._insert_update_records(
            [record], [3, upload["field"]], database=database
        )

        return response

    @SessionContext.with_session
    def get_file(self, url=None, database=None, record=None, field=None, version=0):
        if record and field:
            url = f"https://api.quickbase.com/v1/files/{database or self.database}/{record}/{field}/{version}"
        else:
            url = f"https://api.quickbase.com/v1{url}"

        response = self._request(url, "get", self.headers, json=False)

        return response, response.content

    # ---------------------------------------- misc functions ----------------------------------------
    @SessionContext.with_session
    def import_from_csv(self, records_csv, clist, database=None):
        csv = records_csv.splitlines()
        data = []

        try:
            for recordData in csv:
                record = {}
                for fieldkey, field in enumerate(recordData.split(",")):
                    record[f"{clist[fieldkey]}"] = field

                if len(record) != len(clist):
                    raise IndexError("Record columns and clist lengths mismatch")

                data.append(record)
        except IndexError as e:
            raise IndexError("csv string or clist is invalid") from e

        response = self.add_multiple_records(database=database, data=data)
        return response

    @SessionContext.with_session
    def change_record_owner(self, rid, new_owner, database=None):
        xml_client = XmlQuickbaseClient(
            credentials={
                "realmhost": self.realmhost,
                "base_url": self.base_url,
                "user_token": self.user_token,
                "database": database or self.database,
                "timeout": self.timeout,
            },
            session=self.session,
        )
        response = xml_client.change_record_owner(
            rid, new_owner, database or self.database
        )
        return response

    @SessionContext.with_session
    def get_app(self, app_id: str):
        """
        Get app information from Quickbase
        """
        url = f"https://api.quickbase.com/v1/apps/{app_id}"
        response = self._make_request(
            url=url,
            action="get",
            headers=self.headers,
            json=True,
            params=None,
            data=None,
        )
        return response
