import functools
import requests


class Singleton(type):
    _instances = {}

    def __call__(cls, *args, **kwargs):
        if cls not in cls._instances:
            cls._instances[cls] = super(Singleton, cls).__call__(*args, **kwargs)
        else:
            cls._instances[cls].__init__(*args, **kwargs)
        return cls._instances[cls]

    @classmethod
    def clear(cls, desired_class=None):
        if not desired_class:
            cls._instances = {}
        elif desired_class in cls._instances:
            del cls._instances[desired_class]


class SessionContext:

    def __init__(self): ...

    @classmethod
    def _open_session(cls, client):
        if not client.session:
            client.session = requests.Session()
            return True
        else:
            return False

    @classmethod
    def _close_session(cls, client, force=False):
        if client.session and force:
            client.session.close()
            client.session = None

    @classmethod
    def with_session(cls, func):

        @functools.wraps(func)
        def wrapper(*args, **kwargs):
            client = args[0]
            added_session = cls._open_session(client)

            try:
                return func(*args, **kwargs)
            finally:
                cls._close_session(client, force=added_session)

        return wrapper
