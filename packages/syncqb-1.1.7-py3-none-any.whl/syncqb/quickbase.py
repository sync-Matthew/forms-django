from .qb_errors import QBAuthError, QuickbaseError, QBConnectionError, QBResponseError
from .helpers import Singleton, SessionContext
import requests
from time import sleep


class QuickbaseClient(metaclass=Singleton):
    def __init__(self, credentials, timeout=90, database=None, session=None):
        self.username = credentials.get("username")
        self.password = credentials.get("password")
        self.realmhost = credentials.get("realmhost")
        self.base_url = credentials.get("base_url")
        self.user_token = credentials.get("user_token")
        self.timeout = timeout
        self.database = database

        self.session = session

        if not self.base_url:
            raise QBAuthError("missing base_url")
        if not self.realmhost:
            self.realmhost = self.base_url.split("https://")[1]

    def __str__(self) -> str:
        return self.__name__()

    def __name__(self) -> str:
        return "QuickbaseClient"

    def _make_request(
        self,
        url: str,
        action: str,
        headers: dict,
        data,
        params,
        json=False,
    ):
        kwargs = {
            "headers": headers,
            "timeout": self.timeout,
        }
        if data and headers.get("Content-Type") == "application/json":
            kwargs["json"] = data
        elif data:
            kwargs["data"] = data
        if params:
            kwargs["params"] = params

        if action.lower() == "get":
            response: requests.models.Response = self.session.get(url, **kwargs)
        elif action.lower() == "post":
            response: requests.models.Response = self.session.post(url, **kwargs)
        elif action.lower() == "delete":
            response: requests.models.Response = self.session.delete(url, **kwargs)
        else:
            raise ValueError("invalid action")

        if response.status_code == 401 or response.status_code == 403:
            raise QBAuthError("Invalid credentials")
        elif response.status_code == 404:
            raise QBConnectionError("Connection Error: Invalid URL")
        elif response.status_code == 400:
            raise QuickbaseError("Response Error: Invalid request", response)
        elif response.status_code == 413:
            raise QuickbaseError("Response Error: Request too large", response)
        elif response.status_code == 429:
            raise QBResponseError("Response Error: Too many requests", response)
        elif response.status_code >= 500:
            raise QBResponseError(
                "Response Error: Internal Quickbase Server Error", response
            )

        if json:
            try:
                return response.json()
            except Exception as e:
                raise QuickbaseError(
                    "Response Error: Invalid JSON or no data given", response
                ) from e
        else:
            return response

    @SessionContext.with_session
    def _request(
        self,
        url,
        action,
        headers,
        data=None,
        params=None,
        json=False,
    ):
        tries = 0
        initial_wait_time = 1

        while tries < 10:
            try:
                response = self._make_request(
                    url, action, headers, params=params, data=data, json=json
                )
                return response
            except requests.exceptions.Timeout:
                tries += 1
                sleep(15)
                pass
            except QBResponseError as e:
                if (
                    e.response.status_code == 429 or e.response.status_code >= 500
                ) and initial_wait_time < self.timeout:
                    tries += 1
                    retry_wait_time = e.response.headers.get("retry-after")
                    if retry_wait_time:
                        sleep(int(retry_wait_time))
                    else:
                        sleep(initial_wait_time)
                        initial_wait_time *= 2

                    pass
                else:
                    raise e from e
        raise QBConnectionError("Connection Error: Timeout")
