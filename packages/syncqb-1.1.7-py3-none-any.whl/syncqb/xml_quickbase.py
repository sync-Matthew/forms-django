from .quickbase import QuickbaseClient
from .qb_errors import QBAuthError, QuickbaseError
from .helpers import SessionContext
import os
import chardet
from lxml import etree, html


class XmlQuickbaseClient(QuickbaseClient):

    def __init__(
        self,
        credentials=None,
        timeout=90,
        database=None,
        authenticate=True,
        apptoken=None,
        hours=12,
        ticket=None,
        session=None,
        **kwargs,
    ):
        self.apptoken = apptoken
        self.hours = hours
        self.ticket = None

        if not credentials:
            credentials = kwargs

        if not credentials.get("username") and not credentials.get("user_token"):
            raise QBAuthError(
                "In order to use this SDK, you must provide a Quickbase username and password, missing username."
            )
        if not credentials.get("password") and not credentials.get("user_token"):
            raise QBAuthError(
                "In order to use this SDK, you must provide a Quickbase username and password, missing password."
            )
        super().__init__(
            credentials, timeout=timeout, session=session, database=database
        )

        if authenticate and not self.user_token:
            self.authenticate()
        elif ticket is not None:
            self.ticket = ticket

    def __name__(self) -> str:
        return "XmlQuickbaseClient"

    @SessionContext.with_session
    def _request(self, url, data, method, action):

        if method == "files":
            headers = {"cookie": f"ticket={self.ticket}"}
        else:
            headers = {
                "content-type": "application/xml",
                "QUICKBASE-ACTION": f"API_{method}",
            }
        response = super()._request(url, action, headers, data=data, json=False)
        return response.content

    def _build_xml(self, data):
        if self.user_token:
            data["usertoken"] = self.user_token
        if self.ticket:
            data["ticket"] = self.ticket
        if self.apptoken:
            data["apptoken"] = self.apptoken

        request = etree.Element("qdbapi")
        doc = etree.ElementTree(request)

        def add_sub_element(field, value):
            if isinstance(value, tuple):
                attrib, value = value
                attrib = dict((k, str(v)) for k, v in attrib.items())
            else:
                attrib = {}
            sub_element = etree.SubElement(request, field, **attrib)
            if not isinstance(value, str):
                value = str(value)
            sub_element.text = value

        for field, values in data.items():
            if not isinstance(values, list):
                values = [values]
            for value in values:
                add_sub_element(field, value)
        return etree.tostring(doc, xml_declaration=True, encoding="utf-8")

    def _parse_xml(
        self, response, required_fields=None, qid_headers=False, return_as_dict=True
    ):
        encoding = chardet.detect(response)["encoding"]

        if encoding != "utf-8":
            response = response.decode(encoding, "replace").encode("utf-8")

        if qid_headers:
            return response

        parsed = etree.fromstring(response)

        error_code = parsed.findtext("errcode")

        if error_code != "0":
            raise QuickbaseError(parsed.findtext("errtext"))

        if required_fields:
            required_fields = [str(f) for f in required_fields]
            values = {}
            for field in required_fields:
                if parsed.find(field) is None:
                    raise QuickbaseError(f"Missing required field: {field}")
                values[field] = parsed.find(field).text or ""

            return values
        elif return_as_dict:
            return self._format_etree_as_dict(parsed)
        else:
            return parsed

    def _parse_record_data(self, raw_record_data, return_metadata=False, headers=None):

        records = []
        # obtain and iterate through list of record elements
        records_returned = raw_record_data.xpath(".//record")

        for record in records_returned:
            record_data = {}
            # this will be present if include_rids is provided to do_query
            if record.get("rid"):
                record_data.update({"3": record.get("rid")})
            record_data.update(self._parse_field_data(record))
            records.append(record_data)
        if return_metadata:
            fields_returned = raw_record_data.xpath(".//field")
            fields = {}

            for index, field in enumerate(fields_returned):
                id = field.get("id")
                field_data = {
                    "id": id,
                    "type": field.get("type"),
                    "base_type": field.get("base_type"),
                    "currency_symbol": field.get("currency_symbol"),
                    "label": field.findtext("label"),
                }

                if headers:
                    field_data["label_override"] = headers[index]

                fields[id] = field_data

            return records, fields

        return records

    def _parse_field_data(self, raw_field_data):
        field_data = {}
        # not using 'if not raw_field_data' to hide a future warning to keep console clean
        if raw_field_data is None:
            raw_field_data = []
        if len(raw_field_data) == 0:
            return field_data
        # iterate through each field in the record
        for field in raw_field_data:
            # get the field id or field name, ignoring update_id fields
            fid = field.get("id", field.tag)
            if fid == "update_id":
                continue
            # something is stored in every field.text, most field types store their full values here.
            # two known exceptions to this rule: url and line breaks, handled below
            field_data[fid] = field.text
            # if the field has children, handle them. two possibilities known: url and line breaks
            for child in field:
                # if the child is a url, replace the field text with the url text
                if child.tag == "url":
                    field_data[fid] = child.text
                # if the child is not a url, its a <br/> which has a tail
                elif child.tail is not None:
                    # add the tail to the field value
                    if field_data[fid] is None:
                        field_data[fid] = ""
                    field_data[fid] += child.tail
        return field_data

    def _parse_schema(self, response, select="all"):
        table = response.xpath(".//table")
        if not table:
            return {}
        # should be one table:
        table = table[0]
        table_data = {}
        for tablechild in table:
            tag = tablechild.tag
            # present in both table and app level
            if tag == "name":
                table_data["name"] = tablechild.text
            elif tag == "desc":
                desc = tablechild.text
                for child in tablechild:
                    if child.tail is not None:
                        desc += child.tail
            elif tag == "original":
                for child in tablechild:
                    table_data[child.tag] = child.text
            elif tag == "fields":
                fields = []
                for fieldchild in tablechild:
                    fid = fieldchild.get("id")
                    fieldtype = fieldchild.get("field_type")
                    base_type = fieldchild.get("base_type")
                    field = {
                        "field_id": fid,
                        "field_type": fieldtype,
                        "base_type": base_type,
                    }
                    for child in fieldchild:
                        tag = child.tag
                        field[tag] = child.text
                        if tag == "choices":
                            choices = [c.text for c in child]
                            field[tag] = choices
                    fields.append(field)
                table_data["fields"] = fields
            # exclusive to table level
            elif tag == "queries":
                reports = []
                for querychild in tablechild:
                    qid = querychild.get("id")
                    report = {"qid": qid}
                    for child in querychild:
                        report[child.tag] = child.text
                    reports.append(report)
                table_data["reports"] = reports
            # exclusive to app level
            elif tag == "variables":
                variables = {}
                for child in tablechild:
                    variables[child.get("name")] = child.text
                table_data["variables"] = variables
            elif tag == "chdbids":
                chdbids = {}
                for child in tablechild:
                    chdbids[child.get("name")] = child.text
                table_data["child_tables"] = chdbids

        if select == "all":
            return table_data
        elif select == "reports":
            return table_data.get("reports") or []
        elif select == "fields":
            return table_data.get("fields") or []
        elif select == "table":
            table_data.pop("reports", None)
            table_data.pop("fields", None)
            return table_data
        return {}

    def _parse_csv_response(self, response):
        return_dict = {
            "records_processed": int(response.findtext("num_recs_input") or 0),
            "records_added": int(response.findtext("num_recs_added") or 0),
            "records_edited": int(response.findtext("num_recs_updated") or 0),
            "records_unchanged": int(response.findtext("num_recs_unchanged") or 0),
        }
        record_data = response.find("rids")
        rid_list = []
        if record_data is None:
            return return_dict
        for rid_element in record_data.iter("rid"):
            rid = rid_element.text
            record = {"3": rid}
            field_data = record_data.find('fields[@rid="%s"]' % rid)
            record.update(self._parse_field_data(field_data))
            rid_list.append(record)

        return_dict["records"] = rid_list
        return return_dict

    @SessionContext.with_session
    def _get_qid_headers(self, qid=None, database=None):
        request = {"qid": qid}

        response = self._request(
            f"{self.base_url}/db/{database or self.database}",
            self._build_xml(request),
            "GenResultsTable",
            "POST",
        )
        response = self._parse_xml(response, qid_headers=True)
        dom = html.fromstring(response)

        header_nodes = dom.xpath("//tr[1]/td")[1:-1]

        header_list = []
        for this_node in header_nodes:
            header_list.append(this_node.text_content().strip())

        return header_list

    def _format_field_data(self, data):
        try:
            value = float(data)
            if value.is_integer():
                value = int(value)
        except ValueError:
            value = data

        return value

    def _format_etree_as_dict(self, etree):
        main_tag = etree.tag
        main_dict = {}
        if len(etree):
            # multiple children with identical tags means a list
            if len(set(sub.tag for sub in etree)) == 1 and len(etree) > 1:
                main_dict[main_tag] = []
                for sub_element in etree:
                    main_dict[main_tag].append(self._format_etree_as_dict(sub_element))
            else:
                main_dict[main_tag] = {}
                for sub_element in etree:
                    main_dict[main_tag].update(self._format_etree_as_dict(sub_element))

            return main_dict
        else:
            return {main_tag: etree.text}

    def _get_sort_and_order_lists(self, sort, ascending):
        if not sort or not isinstance(sort, (list, dict)):
            return None, None
        sortlist = []
        orderstr = ""
        if isinstance(sort, dict):
            for fid, order in sort.items():
                sortlist.append(fid)
                orderstr += "D" if order == "DESC" else "A"
        else:
            for fid in sort:
                sortlist.append(fid)
            orderstr += "A" if ascending else "D"

        return sortlist, orderstr

    @SessionContext.with_session
    def authenticate(self):

        url = f"{self.base_url}/db/main"

        request = self._build_xml(
            {
                "username": self.username,
                "password": self.password,
                "hours": self.hours,
                "apptoken": self.apptoken,
            }
        )

        response = self._request(url, request, "Authenticate", "POST")

        response = self._parse_xml(response, required_fields=["ticket", "userid"])

        self.ticket = response["ticket"]
        self.user_id = response["userid"]

    @SessionContext.with_session
    def add_record(
        self,
        fields,
        database=None,
        record_owner=None,
        ignore_error=True,
        uploads=None,
        return_fields=None,
    ):
        request = {"field": []}
        if ignore_error:
            request["ignoreError"] = "1"
        if return_fields:
            request["clist"] = ".".join([str(x) for x in return_fields])
        for field, value in fields.items():
            request["field"].append(({"fid": field}, value))

        if uploads:
            for upload in uploads:
                request["field"].append(
                    (
                        {"fid": upload["field"], "filename": upload["filename"]},
                        upload["value"],
                    )
                )

        response = self._request(
            f"{self.base_url}/db/{database or self.database}",
            self._build_xml(request),
            "AddRecord",
            "POST",
        )

        response = self._parse_xml(response, return_as_dict=False)
        rid = int(response.findtext("rid"))
        if return_fields or record_owner:
            return_data = {"3": rid}
            return_data.update(self._parse_field_data(response.find("record")))
        else:
            return_data = rid

        if record_owner:
            change_response = self.change_record_owner(
                rid, record_owner, database=database
            )
            errcode = (change_response.get("qdbapi") or {}).get("errcode")
            return_data.update({"owner_changed": errcode == "0"})
        return return_data

    @SessionContext.with_session
    def edit_record(self, rid, fields, database=None, uploads=None, return_fields=None):
        request = {"rid": rid, "field": []}

        for field, value in fields.items():

            request["field"].append(({"fid": field}, value))
        if return_fields:
            request["clist"] = ".".join([str(x) for x in return_fields])

        if uploads:
            for upload in uploads:
                request["field"].append(
                    (
                        {"fid": upload["field"], "filename": upload["filename"]},
                        upload["value"],
                    )
                )

        response = self._request(
            f"{self.base_url}/db/{database or self.database}",
            self._build_xml(request),
            "EditRecord",
            "POST",
        )
        response = self._parse_xml(response, return_as_dict=False)
        rid = int(response.findtext("rid"))
        if return_fields:
            return_data = {"3": rid}
            return_data.update(self._parse_field_data(response.find("record")))
        else:
            return_data = rid

        return return_data

    @SessionContext.with_session
    def delete_record(self, rid=None, key=None, database=None):
        if not rid and not key:
            raise TypeError("Must provide a rid or key")

        request = {}
        if rid:
            request["rid"] = rid
        elif key:
            request["key"] = key

        response = self._request(
            f"{self.base_url}/db/{database or self.database}",
            self._build_xml(request),
            "DeleteRecord",
            "POST",
        )
        return self._parse_xml(response, required_fields=["rid"])

    @SessionContext.with_session
    def purge_records(self, rids=None, query=None, qid=None, database=None):
        # technically none of these are required by quickbase, but results in deleting ALL records
        # so we require at least one to prevent accidental purge of all records
        if not any([rids, query, qid]):
            raise TypeError("Must provide at least one of rids, query, or qid")

        request = {}
        if rids:
            rids = [str(rid) for rid in rids]
            query = "OR".join(["{3.EX.'%s'}" % rid for rid in rids])
        if query:
            request["query"] = query
        elif qid:
            request["qid"] = qid

        response = self._request(
            f"{self.base_url}/db/{database or self.database}",
            self._build_xml(request),
            "PurgeRecords",
            "POST",
        )
        return self._parse_xml(response)

    @SessionContext.with_session
    def do_query(
        self,
        query=None,
        qid=None,
        query_params=None,
        columns=None,
        sort=None,
        structured=True,
        num=None,
        skip=None,
        ascending=True,
        include_rids=False,
        return_metadata=False,
        qid_custom_headers=False,
        database=None,
    ):
        if not query_params:
            query_params = {}
        request = {}
        if query:
            request["query"] = query
        elif qid:
            request["qid"] = qid
        else:
            raise ValueError("Must provide a query or qid")

        if columns:
            columns = [str(c) for c in columns]
            request["clist"] = ".".join(str(c) for c in columns)

        sortlist, orderstr = self._get_sort_and_order_lists(sort, ascending)

        if sortlist:
            request["slist"] = ".".join([str(fid) for fid in sortlist])

        if structured:
            request["fmt"] = "structured"

        if query_params:

            for this_key, this_value in query_params.items():
                request[this_key] = this_value

        options = []
        if num is not None:
            options.append("num-{0}".format(num))
        if skip is not None:
            options.append("skp-{0}".format(skip))
        if orderstr:
            options.append(f"sortorder-{orderstr}")
        if options:
            request["options"] = ".".join(options)

        if include_rids:
            request["includeRids"] = 1

        if qid_custom_headers and qid:

            headers = self._get_qid_headers(qid=qid, database=database or self.database)

        else:
            headers = None

        response = self._request(
            f"{self.base_url}/db/{database or self.database}",
            self._build_xml(request),
            "DoQuery",
            "POST",
        )

        response = self._parse_xml(response, return_as_dict=False)

        return self._parse_record_data(response, return_metadata, headers)

    @SessionContext.with_session
    def get_schema(self, database=None, get_xml=False, select=None):
        response = self._request(
            f"{self.base_url}/db/{database or self.database}",
            self._build_xml({}),
            "GetSchema",
            "POST",
        )

        response = self._parse_xml(response, return_as_dict=False)

        if get_xml:
            return etree.tostring(response)

        return self._parse_schema(response, select=select or "all")

    @SessionContext.with_session
    def get_file(
        self, fname=None, rid=None, fid=None, version=0, database=None, url=None
    ):
        if not url:
            url = f"{self.base_url}/up/{database or self.database}/a/r{rid}/e{fid}/v{version}"
            response = self._request(url, self._build_xml({}), "files", "POST")
            return fname, response
        else:
            response = self._request(url, self._build_xml({}), "files", "GET")
            return os.path.basename(url), response

    @SessionContext.with_session
    def upload_file(self, rid, upload, database=None):
        request = {
            "rid": rid,
            "field": [
                (
                    {"fid": upload["field"], "filename": upload["filename"]},
                    upload["value"],
                )
            ],
        }

        response = self._request(
            f"{self.base_url}/db/{database or self.database}",
            self._build_xml(request),
            "UploadFile",
            "POST",
        )

        return self._parse_xml(response)

    @SessionContext.with_session
    def import_from_csv(
        self,
        records_csv,
        clist,
        merge_field=None,
        clist_output=None,
        skipfirst=False,
        database=None,
        chunk=None,
    ):
        # support function to generate import request and return response
        def _run_import(records_csv, clist, clist_output, skipfirst, database):
            request = {
                "clist": ".".join(str(c) for c in clist),
                "records_csv": records_csv,
            }
            if merge_field:
                request["mergeFieldId"] = merge_field
            if clist_output:
                request["clist_output"] = ".".join(str(c) for c in clist_output)

            if skipfirst:
                request["skipfirst"] = 1

            response = self._request(
                f"{self.base_url}/db/{database or self.database}",
                self._build_xml(request),
                "ImportFromCSV",
                "POST",
            )
            return self._parse_xml(response, return_as_dict=False)

        records_list = records_csv.splitlines()

        # confirm that records_csv is not empty and record line count
        line_count = len(records_list)
        if chunk:
            print(f"Importing {line_count} records in chunks of {chunk} records")
            chunk_size = chunk
            offset = 0
            records_processed = 0
            records_added = 0
            records_edited = 0
            records_unchanged = 0
            records = []
            while offset < line_count:
                # prevent skipfirst being executed per chunk
                if offset != 0:
                    skipfirst = False

                chunks = records_list[offset : offset + chunk_size]
                offset += chunk_size
                records_csv = "\n".join(chunks)
                print(
                    f"Importing records {offset - chunk_size + 1} to {offset} of {line_count} records"
                )
                print(f"Importing {len(chunks)} records")
                raw_response = _run_import(
                    records_csv, clist, clist_output, skipfirst, database
                )
                parsed_response = self._parse_csv_response(raw_response)
                records_processed += parsed_response.get("records_processed")
                records_added += parsed_response.get("records_added")
                records_edited += parsed_response.get("records_edited")
                records_unchanged += parsed_response.get("records_unchanged")
                records.extend(parsed_response.get("records") or [])

            return {
                "records_processed": records_processed,
                "records_added": records_added,
                "records_edited": records_edited,
                "records_unchanged": records_unchanged,
                "records": records,
            }

        else:
            response = _run_import(
                records_csv, clist, clist_output, skipfirst, database
            )

            return self._parse_csv_response(response)

    @SessionContext.with_session
    def get_user_info(self, email):
        request = {}
        request["email"] = email

        response = self._request(
            f"{self.base_url}/db/main", self._build_xml(request), "GetUserInfo", "POST"
        )

        response = self._parse_xml(response, return_as_dict=False)

        user_info = {}

        user_info["id"] = response.xpath(".//user")[0].attrib["id"]
        user_info["first_name"] = response.xpath(".//firstName")[0].text
        user_info["last_name"] = response.xpath(".//lastName")[0].text
        user_info["login"] = response.xpath(".//login")[0].text
        user_info["email"] = response.xpath(".//email")[0].text
        user_info["screen_name"] = response.xpath(".//screenName")[0].text
        user_info["is_verified"] = response.xpath(".//isVerified")[0].text
        user_info["external_auth"] = response.xpath(".//externalAuth")[0].text

        return user_info

    @SessionContext.with_session
    def change_record_owner(self, rid, new_owner_email, database=None):
        request = {"rid": rid, "newowner": new_owner_email}

        response = self._request(
            f"{self.base_url}/db/{database or self.database}",
            self._build_xml(request),
            "ChangeRecordOwner",
            "POST",
        )

        return self._parse_xml(response)
